# Three-minute video plan

**0:00–0:20 — Intro:** “We are [Team Name]. CyberShield AI is a prototype that helps people spot warning signs in suspicious messages and links.”

**0:20–0:40 — Evidence:** Show one verified Malaysian scam statistic with source name and date on screen.

**0:40–1:20 — App demo:** Paste the fictional message `Your account is locked. Verify your account immediately at http://example.invalid`. Show the score, reasons and advice. Try an ordinary message too.

**1:20–2:15 — IBM Z evidence:** Show your actual LinuxONE portal instance and SSH terminal. Run `uname -m` and show `s390x`. Show the app running from that instance. Say it is hosted on LinuxONE only if it really is.

**2:15–2:40 — Design and limits:** Show Browser → Flask app → rule checks → explanations. Explain that it is a rule-based first version, not a definitive security verdict.

**2:40–3:00 — Close:** Summarise the benefit and display the GitHub/GitLab link.

Checklist: under 3 minutes; hide secrets; do not fake IBM Z evidence; show repository URL; use fictional input.

from flask import Flask, request, render_template_string
import re
from urllib.parse import urlparse

app = Flask(__name__)
PAGE = """
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>CyberShield AI</title><style>
body{font-family:Arial;background:#f3f6fb;color:#172033;margin:0}main{max-width:800px;margin:35px auto;padding:20px}
.card{background:white;border:1px solid #dce3ee;border-radius:16px;padding:24px}h1{color:#12315b}
textarea{width:100%;min-height:140px;padding:12px;box-sizing:border-box;border:1px solid #bdc8d8;border-radius:9px;font:inherit}
button{background:#154b8a;color:white;border:0;border-radius:8px;padding:12px 18px;margin-top:12px;cursor:pointer}
.tag{display:inline-block;padding:6px 10px;border-radius:20px;background:#fff0d6;color:#774600;font-weight:bold}
.high{background:#ffe2e2;color:#8a1c1c}.safe{background:#e1f6e9;color:#14532d}.muted{color:#596579}
.note{background:#eef4fc;padding:12px;border-radius:8px}li{margin:8px 0}
</style></head><body><main><div class="card">
<h1>🛡️ CyberShield AI</h1><p class="muted">Phishing and online scam risk indicator prototype</p>
<form method="post"><label><b>Paste a suspicious message or URL</b></label>
<textarea name="message" maxlength="5000" required placeholder="Example: Your account is locked. Verify immediately at http://example.invalid">{{ message }}</textarea>
<button type="submit">Check risk indicators</button></form>
{% if result %}<hr><h2>Assessment</h2><p><span class="tag {{ result.cls }}">{{ result.level }} risk indicators</span></p>
<p><b>Risk score:</b> {{ result.score }}/100</p><p>{{ result.summary }}</p><h3>What we noticed</h3><ul>{% for x in result.reasons %}<li>{{ x }}</li>{% endfor %}</ul>
<h3>Recommended next steps</h3><ul><li>Do not click the link until you verify it.</li><li>Contact the organisation through its official app, website typed manually, or a known phone number.</li><li>Never share passwords, OTPs, PINs, or banking details.</li></ul>
<div class="note">This is a rule-based educational prototype. A low score does not prove a message or URL is safe.</div>{% endif %}
<p class="muted">Do not enter real credentials or private information. Submitted text is not intentionally saved by this demo.</p>
</div></main></body></html>
"""

def analyse(text):
    lower = text.lower()
    score, reasons = 0, []
    checks = [
        (r"\b(urgent|immediately|within 24 hours|act now|final warning)\b", 20, "Uses urgency or pressure to make you act quickly."),
        (r"\b(password|one[- ]time password|otp|pin|verify your account|confirm your account)\b", 25, "Mentions account verification or sensitive authentication information."),
        (r"\b(prize|winner|claim your reward|free gift|cash prize)\b", 15, "Promises a prize or reward that may be used as bait."),
        (r"\b(account (is )?(locked|suspended|blocked)|unusual activity)\b", 20, "Claims there is an account problem to prompt a response."),
        (r"\b(transfer money|send money|payment failed|refund pending)\b", 20, "Mentions payment or money transfer activity that should be verified.")
    ]
    for pattern, points, reason in checks:
        if re.search(pattern, lower):
            score += points
            reasons.append(reason)
    urls = re.findall(r"(?:https?://|www\.)\S+", text, flags=re.I)
    for raw in urls:
        url = raw.rstrip(".,!?;:)]}")
        parsed = urlparse(url if url.lower().startswith(("http://","https://")) else "http://" + url)
        host = (parsed.hostname or "").lower()
        if parsed.scheme == "http":
            score += 10; reasons.append("Contains a link using HTTP rather than HTTPS.")
        if host.count("-") >= 2:
            score += 10; reasons.append("The domain contains multiple hyphens, which can be a warning sign.")
        if any(w in host for w in ["login","verify","secure","account","update"]):
            score += 10; reasons.append("The domain contains a term sometimes used to imitate account pages.")
    if not reasons:
        reasons.append("No obvious indicators from this small set of rules were detected. This does not mean the message is safe.")
    reasons = list(dict.fromkeys(reasons))
    score = min(score, 100)
    if score >= 50:
        level, cls, summary = "High", "high", "Several warning signs were detected. Verify independently before acting."
    elif score >= 25:
        level, cls, summary = "Moderate", "", "Some warning signs were detected. Verify the sender and request."
    else:
        level, cls, summary = "Low", "safe", "Few warning signs were detected, but this cannot establish safety."
    return {"score":score,"reasons":reasons,"level":level,"cls":cls,"summary":summary}

@app.route("/", methods=["GET","POST"])
def index():
    message, result = "", None
    if request.method == "POST":
        message = request.form.get("message","")[:5000]
        if message.strip(): result = analyse(message)
    return render_template_string(PAGE, message=message, result=result)

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)

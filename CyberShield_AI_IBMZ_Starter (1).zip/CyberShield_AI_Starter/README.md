# CyberShield AI — IBM Z Datathon starter

**Required title format:** `[YOUR TEAM NAME]_IBM Z Datathon 2026 Project`

## What this prototype does
A Flask web app that checks pasted text for a small set of common scam warning signs and explains the indicators. It is transparent and rule-based. It is **not an AI model**, does not check threat-intelligence databases, and cannot prove a message is safe.

## Run locally
Requires Python 3.10+.

```bash
python -m venv .venv
# Windows PowerShell: .venv\\Scripts\\Activate.ps1
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000.

## LinuxONE deployment plan
1. Register at https://community.ibm.com/zsystems/l1cc/ and use Datathon event code `SSF2026` when prompted. Access may not be instant.
2. Create the event's available LinuxONE instance and save the SSH private key securely.
3. SSH to the instance as `linux1` using the IP and private key shown in the portal.
4. Run `uname -m`; IBM Z/LinuxONE Linux should report `s390x`.
5. Upload this project or clone your Git repo. Install Python and pip for the selected Linux distribution, create a virtual environment, install requirements, and test the app.
6. If you need an externally reachable demo, configure an appropriate production server and network rules. Do not expose Flask's development server publicly. If networking is too difficult, record a browser demo plus genuine terminal/portal evidence.
7. Capture the actual portal instance status, terminal, `uname -m`, app running, and one test. Hide keys, tokens, and personal account details.

**Do not claim deployment until the app is actually running on the LinuxONE instance.** Do not claim watsonx.ai or QRadar integration unless you implement and test it.

## Architecture
Browser → Flask app → transparent rule checks → risk score, reasons, safety guidance.

## Suggested test cases
- `Your account is locked. Verify your account immediately at http://example.invalid` — should trigger several indicators.
- `Congratulations, claim your free gift now` — should trigger reward language.
- `Hi, are we still meeting at 3 pm?` — should show no obvious indicators while reminding users that low score does not mean safe.

## Limitations and privacy
This is a teaching prototype, not a production anti-phishing service. Simple rules can miss scams or flag legitimate messages. Do not paste real passwords, OTPs, banking details, or private messages. Do not claim an accuracy rate without a labelled evaluation dataset and documented tests.

## Final submission
Replace team name, add actual team members and description, push source code to a public/reviewer-accessible GitHub/GitLab repository or use the permitted ZIP upload. Include a 3-minute max video and optional flowchart. Only describe features you actually implemented and tested.
